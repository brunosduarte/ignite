
<img src="https://storage.googleapis.com/golden-wind/experts-club/capa-github.svg" />

# Integrando Firebase Authentication com React

Nessa aula, irei mostrar como integrar a autenticaçao do Firebase, em aplicaçao React.js, iremos 
ver as melhores formas de fazer login, signup e reset password tudo isso com Firebase Authtentication

## Expert

| [<img src="https://avatars.githubusercontent.com/u/19227867?v=4" width="75px;"/>](https://github.com/ismaelash) |
| :----------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
|                                                             [Ismael Ash](https://github.com/ismaelash)                                                             |

TAGS: React, Firebase, Firebase Authentication
